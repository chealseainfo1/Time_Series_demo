def get_metric_style_and_text(metric, value):
    if metric in ["MDA", "NMDV"]:
        if value < -0.5:
            return "Calidad baja", "#f8d7da"
        elif -0.5 <= value < 0:
            return "Calidad media-baja", "#fff3cd"
        elif 0 <= value < 0.5:
            return "Calidad media-alta", "#d1ecf1"
        else:
            return "Calidad alta", "#d4edda"
    elif metric == "MASE":
        if value < 0:
            return "Calidad baja", "#f8d7da"
        elif 0 <= value <= 0.75:
            return "Calidad media", "#fff3cd"
        else:
            return "Calidad óptima", "#d4edda"
    return "Desconocida", "#e2e3e5"
