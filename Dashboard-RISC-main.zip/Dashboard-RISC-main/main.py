from dash import Dash
import dash_bootstrap_components as dbc
from layout.layout import create_layout
from callbacks.update_threat import register_callbacks

# Inicializar la app
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = 'Dashboard de Amenazas INCIBE'

# Cargar layout
app.layout = create_layout()

# Registrar callbacks
register_callbacks(app)

if __name__ == '__main__':
    app.run(debug=True)
