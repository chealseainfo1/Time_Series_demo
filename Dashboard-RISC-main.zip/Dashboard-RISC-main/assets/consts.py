# Paleta de colores primarios
COLOR_YELLOW = 'rgb(255, 221, 0)'       # Amarillo
COLOR_RED = 'rgb(231, 49, 55)'          # Rojo
COLOR_GRAY = 'rgb(104, 117, 126)'       # Gris
COLOR_DARK_GRAY = 'rgb(75, 92, 102)'    # Gris oscuro
# Colores adicionales
COLOR_DEEP_RED = 'rgb(121, 38, 42)'          # Rojo oscuro
COLOR_BLOOD_RED = 'rgb(197, 52, 58)'         # Rojo sangre
COLOR_LIME_GREEN = 'rgb(138, 208, 0)'        # Verde lima
COLOR_GOLDEN_YELLOW = 'rgb(235, 208, 0)'     # Amarillo dorado
COLOR_BRIGHT_YELLOW = 'rgb(248, 220, 0)'     # Amarillo brillante
COLOR_SKY_BLUE = 'rgb(0, 156, 221)'          # Azul cielo
COLOR_CHARCOAL = 'rgb(74, 81, 88)'           # Carbón
COLOR_SOFT_GRAY = 'rgb(107, 117, 125)'       # Gris suave
COLOR_ORANGE_AMBER = 'rgb(238, 150, 0)'      # Naranja ámbar

# Tipografía
FONT_FAMILY = "'Open Sans', sans-serif"

FONT_WEIGHT_BOLD = '700'
FONT_WEIGHT_REGULAR = '400'
FONT_WEIGHT_LIGHT = '300'

FINANCIAL_TEXT = "Esta web resulta del Proyecto Estratégico Ciencia de datos para un modelo de inteligencia artificial en ciberseguridad (C073/23) , fruto del convenio de colaboración suscrito entre el Instituto Nacional de Ciberseguridad (INCIBE) y la Universidad de León. Esta iniciativa se realiza en el marco de los fondos del Plan de Recuperación, Transformación y Resiliencia, financiados por la Unión Europea (Next Generation)."

COLOR_PALETTE = [
    COLOR_YELLOW,
    COLOR_RED,
    COLOR_LIME_GREEN,
    COLOR_BLOOD_RED,
    COLOR_SKY_BLUE,
    COLOR_ORANGE_AMBER,
    COLOR_GRAY,
    COLOR_SOFT_GRAY,
    COLOR_DEEP_RED
]
