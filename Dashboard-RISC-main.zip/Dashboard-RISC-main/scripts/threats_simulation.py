# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 19:59:06 2025
@author: amunc
"""

## Paquetes ###################################################################
from random import choices, randrange
import datetime 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#%% Crear database de mentirijilla ################################################

# n = 1000
# fuente = list('abcdefghijklmnopqrstuvwxyz')
# threat = ["bot", "spyware", "phishing", "virus", "worm", "backdoor"]
# df1 = choices(fuente, k=n)
# df2 = choices(threat, k=n)

# def random_date(start, l):
#     current = start
#     while l >= 0:
#         curr = current + datetime.timedelta(minutes=randrange(60 * 24))
#         yield curr
#         l -= 1

# startDate = datetime.datetime(2025, 6, 17, 0, 0)
# df3 = list(random_date(startDate, n - 1))
# df3.sort()

# df = pd.DataFrame([df3, df1, df2]).transpose()
# df.columns = ['timestamp', 'source', 'threat']
# df['timestamp'] = pd.to_datetime(df['timestamp'])


# Lista de clases en orden
clases = [
    "Bot,C&C", "Botnet", "C&C", "Compromised", "DGA", "Defacement",
    "Exposed", "Fake", "Malicious", "Malware", "Phishing", "Security check",
    "Spam", "Tor", "Vulnerable"
]

# Crear diccionario: nombre -> índice
clase_a_indice = {clase: i for i, clase in enumerate(clases)}



#%% Función original sin resample #################################################
def integrar_tabla(df, idx, target, dtau_seconds):
    df = df.copy()
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    dtau = datetime.timedelta(seconds=dtau_seconds)
    dtau_int = int(dtau.total_seconds())

    dtimetotal = df['timestamp'].iloc[-1] - df['timestamp'].iloc[0]
    dtimetotal_int = int(dtimetotal.total_seconds())

    df_alt = df.copy()
    df_alt['interval'] = ((df['timestamp'] - df['timestamp'].iloc[0]).dt.total_seconds() // dtau_int).astype(int)

    cuantos_ts = (dtimetotal_int // dtau_int) + 1
    x = np.zeros(cuantos_ts)

    colname = df.columns[idx]
    filtered_df = df_alt[df_alt[colname] == target]

    if not filtered_df.empty:
        counts = filtered_df.groupby('interval').size()
        valid_indices = counts.index[counts.index < cuantos_ts]
        x[valid_indices.astype(int)] = counts.loc[valid_indices].values

    return x

#%% Nueva función usando resample #################################################

def integrar_con_resample(df, idx, target, dtau_seconds):
    """
    Cuenta ocurrencias del 'target' usando resample desde el primer timestamp (igual que manual).
    """
    df = df.copy()
    df.columns = ['timestamp', 'source', 'threat']
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Obtener el primer timestamp
    start_time = df['timestamp'].min()

    # Crear una nueva columna de timestamps artificiales que parten del start_time
    # Antes (Mou)
    # df['aligned_timestamp'] = start_time + (df['timestamp'] - start_time)
    # Ahora (Lucía) (quiero que hagan exactamente lo mismo para que sean comparables):
    df['aligned_timestamp'] = start_time + (df['timestamp'] - start_time)

    # Usar esa columna como índice para resamplear
    df.set_index('aligned_timestamp', inplace=True)

    intervalo = f"{dtau_seconds}s"
    columna = df.columns[idx]  # idx=2 para 'threat' → columna=1

    # Aplicar filtro y resample
    serie = df[df[columna] == target].resample(intervalo, origin=start_time).size().fillna(0)

    return serie.to_numpy()

#%% Comparar resultados ###########################################################
def main(threat_type="Botnet"):
    data = pd.read_csv(r'assets\csvs\df_anonimizada.csv', encoding='utf-8', delimiter=',')
    print("waa", data.loc[clase_a_indice[threat_type]].head())
    target = threat_type
    dtau_seconds = 3600


    serie_manual = data.loc[clase_a_indice[threat_type]].to_numpy()
    print(f"Serie manual: {serie_manual}")
    serie_resample = data.loc[clase_a_indice[threat_type]].to_numpy()
    print(f"Serie resample: {serie_resample}")

    return serie_manual, serie_resample, dtau_seconds

if __name__ == "__main__":
    main()