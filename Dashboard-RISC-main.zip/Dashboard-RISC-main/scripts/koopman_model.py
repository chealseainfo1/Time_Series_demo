import numpy as np
from typing import Callable

static_dicts: list[list[Callable[[float], float]]] = [
  [lambda x: x, lambda x: 1, lambda x: np.sin(x), lambda x: np.cos(x), lambda x: np.sin(2*x), lambda x: np.cos(2*x)],
  [lambda x: x, lambda x: 1, lambda x: x**2, lambda x: x**3, lambda x: x**4],
  [lambda x: x, lambda x: 1, lambda x: np.sin(x), lambda x: np.cos(x)],
]

def create_fdict(g: list[Callable[[float], float]]) -> Callable[[np.array], np.array]:
  """
    Crea un Diccionario de funciones partiendo de una lista de s funciones g_i: R -> R

    El diccionario de funciones devuelto es una función g: R^n -> R^(s x n)
    Donde g(x) = [g_1(x), ..., g_s(x)]^T
  """
  return lambda x: np.vstack([np.vectorize(g_f, otypes=[np.matrix])(x).reshape((1, -1)) for g_f in g], dtype=float, casting='unsafe') #Casting 'unsafe' permite a la función castear arrays (object) a arrays de float. Dará errores si no se cumple el contrato

def get_koopman(X: np.array, g: Callable[[np.array], np.array]) -> np.array:
  """
    Implementa Algoritmo 1 de doi: 10.1109/ACCESS.2021.3097834
    
    X = {x(t), ..., x(t+m-1)} es una ventana de una serie temporal
    g = {g_1, g_2, ... g_s} es el diccionario de funciones

    Hace EDMD de Y_0 e Y_1 para obtener Koopman
    Y_0 = g(X[:-1]) serían los "inputs"
    e
    Y_1 = g(X[1:]) serían los "outputs" a predecir

    de forma que K @ g(Y_0) = Y_1.
    Donde K es la matriz que aproxima el operador de Koopman.

    Por tanto (EDMD),
    K = [1, 0, ..., 0] @ Y_1 @ (Y_0)^+

    Donde + denota la pseudo inversa.
  """
  Y_0 = g(X[:-1])
  Y_1 = g(X[1:])
  indexer = np.zeros(Y_1.shape[0])
  indexer[0] = 1
  return indexer @ Y_1 @ np.linalg.pinv(Y_0)

def one_step_pred(X: np.array, T: int, g: Callable, s: int) -> np.array:
  """
    Implementa OneStepPred de doi: 10.1109/ACCESS.2021.3097834

    X = {x(t), x(t+1), ..., x(T-1), x(T)} es una ventana de una serie temporal donde T+1 es el valor que queremos predecir

    g = {g_1, g_2, ... g_s} es el diccionario de funciones que utilizaremos para aproximar el operador de Koopman

    s es el tamaño de la ventana para aproximar el operador de Koopman
  """
  K = get_koopman(X[T-s:T], g)
  return K @ g(X[T])

def predict_test(X: np.array, g: Callable, m:int, p:float) -> np.array:
  """
    Implementa Algoritmo2 de doi: 10.1109/ACCESS.2021.3097834

    X = {x(t), x(t+1), ..., x(t+m), ..., x(T)} es una ventana de una serie temporal
    m es el tamaño de la ventana de dataset
    p en [0, 1] es la proporción de datos de train
    g = {g_1, g_2, ... g_s} es el diccionario de funciones que utilizaremos para aproximar el operador de Koopman

    Aproxima el operador de Koopman utilizando los datos de train {x(t), ..., x(t+m*p)} y predice el valor de test {x(t+m*p+1), x(t+m+1)}.
  """
  i_sep = int(m*p) # redondeamos por debajo el índice de separación entre test y train 
  K = get_koopman(X[:(i_sep+1)], g)
  return K @ g(X[i_sep: m])

def MDA(x_pred, x_real):
  """
    Implementa MDA de doi: 10.1109/ACCESS.2021.3097834
    
    x_real son los datos reales
    x_pred son las predicciones correspondientes a x_real de manera que en
            un mundo ideal x_real(i)==x_pred(i) para todo i
            
    Calcula la Mean Directional Accuracy
  """
  if len(x_pred)!=len(x_real): 
      raise Exception("Los dos argumentos tienen que tener la misma longitud")
  
  DA1 = np.array([(x_pred[1:]-x_pred[:-1])*(x_real[1:]-x_real[:-1])>0])*1
  DA2 = np.array(x_pred[1:]==x_real[1:])*np.array(x_real[1:]==x_real[:-1])*1
  DA= (DA1+DA2)*2-1     

  return np.mean(DA)

def MDV(x_pred, x_real):
  """
    Implementa MDV de doi: 10.1109/ACCESS.2021.3097834
    
    x_real son los datos reales
    x_pred son las predicciones correspondientes a x_real de manera que en
            un mundo ideal x_real(i)==x_pred(i) para todo i
            
    Calcula el Mean Directional forecast Value
  """
  if len(x_pred)!=len(x_real): 
      raise Exception("Los dos argumentos tienen que tener la misma longitud")
  
  DA1 = np.array([(x_pred[1:]-x_pred[:-1])*(x_real[1:]-x_real[:-1])>0])*1
  DA2 = np.array(x_pred[1:]==x_real[1:])*np.array(x_real[1:]==x_real[:-1])*1
  DA= (DA1+DA2)*2-1 
  DV = abs(x_real[1:]-x_real[:-1])*(DA)          

  return np.mean(DV)

def NMDV(x_pred, x_real):
  """
    Implementa NMDV de doi: 10.1109/ACCESS.2021.3097834
    
    x_real son los datos reales
    x_pred son las predicciones correspondientes a x_real de manera que en
            un mundo ideal x_real(i)==x_pred(i) para todo i
            
    Calcula el Normalized Mean Directional forecast Value
  """
  if len(x_pred)!=len(x_real): 
      raise Exception("Los dos argumentos tienen que tener la misma longitud")
  
  DA1 = np.array([(x_pred[1:]-x_pred[:-1])*(x_real[1:]-x_real[:-1])>0])*1
  DA2 = np.array(x_pred[1:]==x_real[1:])*np.array(x_real[1:]==x_real[:-1])*1
  DA= (DA1+DA2)*2-1 
  DV = abs(x_real[1:]-x_real[:-1])*(DA) 
  numerador = np.sum(DV)
  denominador = np.sum(abs(x_real[1:]-x_real[:-1]))
  if denominador==0:
      if numerador==0:
          return 1
      else:
          return 0
  NDV = numerador/denominador     
  return NDV

def MASE(x_pred, x_real):
  """
    Implementa una métrica basada en MASE (Mean Absolute Scaled Error)
    
    x_real son los datos reales
    x_pred son las predicciones correspondientes a x_real de manera que en
            un mundo ideal x_real(i)==x_pred(i) para todo i
            
    Calcula 1-MASE, de manera que  1 == mejor valor.
  """
  if len(x_pred)!=len(x_real): 
      raise Exception("Los dos argumentos tienen que tener la misma longitud")
  
  error = x_pred - x_real
  T = len(x_pred) 
  sumatorio = np.sum(abs(x_real[1:]-x_real[:-1]))
  if sumatorio == 0:
      return ("Estás intentando predecir una serie cte :/")
  q = error / (sumatorio/(T-1))
  MASE = 1 - np.mean(abs(q))
  return MASE

def rolling_cross_validation(X: np.array, g: Callable, m: int, p: float) -> float:
  """
    Implementa Algoritmo3 de doi: 10.1109/ACCESS.2021.3097834

    X = {x(t), x(t+1), ..., x(t+m), ..., x(T)} es una ventana de una serie temporal
    m es el tamaño de la ventana de validación
    g = {g_1, g_2, ... g_s} es el diccionario de funciones que utilizaremos para aproximar el operador de Koopman
    p en [0, 1] es la proporción de datos de train

    Hace predicciones sobre todas las ventanas disjuntas de tamaño m del dataset y devuelve el MDA.
  """
  ventanas = np.arange(0, X.shape[0], step=m, dtype=int)
  
  x_pred = np.array([])
  x_real = np.array([])

  i_sep = int(m*p)

  for t in ventanas:
    x_pred = np.hstack((x_pred, predict_test(X[t:], g, m, p)))
    x_real = np.hstack((x_real, X[t+i_sep+1:t+m+1]))
    
  # Esto es muy sucio pero hasta que se arregle de otra forma
  # Creo que el problema es que si x_real de pilla el último, 
  # x_pred incluye una predicción que x_real no tiene
  if len(x_pred)!=len(x_real):
        x_pred = x_pred[:-1]
 
  return MDA(x_pred, x_real), MDV(x_pred, x_real), NMDV(x_pred, x_real), MASE(x_pred, x_real) # type: ignore

def prediccion_con_calidad(X: np.array, g: Callable, F: int, p: float):
    """
      Implementa Algoritmo3 de doi: 10.1109/ACCESS.2021.3097834

      X = {x(t), x(t+1), ..., x(t+m), ..., x(T)} es una ventana de una serie temporal
      F es el tamaño de predicción
      g = {g_1, g_2, ... g_s} es el diccionario de funciones que utilizaremos para aproximar el operador de Koopman
      p en [0, 1] es la proporción de datos de train

      Hace prediccion al futuro y devuelve la calidad de las predicciones de mismo tipo en el pasado
    """
    m = int(F/(1-p))
    if len(X)<(m-1):
        raise  Exception("No hay suficientes datos para predecir tanto. ¡Reduce F o p!")
    calidad = rolling_cross_validation(X, g, m, p)
    X_en_uso = X[len(X)-(m-F):]
    X_pred = np.zeros(F)
    for i in range(F):
        X_pred[i] = float(one_step_pred(X_en_uso, len(X_en_uso)-1 , g, len(X_en_uso)-1).item())
        X_en_uso = X_en_uso[1:]
        X_en_uso = np.append(X_en_uso, X_pred[i])
        
    return X_pred, calidad

if __name__ == "__main__":
  
  X = np.linspace(0, 99, num=100)
  g = create_fdict(static_dicts[0]) #0 is the extended trignonometric dict, 1 is the polynomial dict, 2 is the simple trigonometric dict
  print(rolling_cross_validation(X, g, 20, 0.8))
