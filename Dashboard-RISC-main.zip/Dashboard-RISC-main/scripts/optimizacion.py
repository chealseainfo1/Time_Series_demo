# -*- coding: utf-8 -*-
"""
Created on Mon Jun 30 10:56:41 2025

@author: Alumno
"""
import itertools
import optuna
import numpy as np
from typing import Callable
from scripts.koopman_model import prediccion_con_calidad, create_fdict

# PARA EJECUTAR ESTO:
    # TENER LA FUNCIÓN prediccion_con_calidad CARGADA !!!! (está en koopman_operator_prediction)
    # TENER LA SERIE TEMPORAL EN serie_temporal
    # o cambiar la línea 80 :)
    


# def create_fdict(g: list[Callable[[float], float]]) -> Callable[[np.array], np.array]:
#   """
#     Crea un Diccionario de funciones partiendo de una lista de s funciones g_i: R -> R

#     El diccionario de funciones devuelto es una función g: R^n -> R^(s x n)
#     Donde g(x) = [g_1(x), ..., g_s(x)]^T
#   """
#   return lambda x: np.vstack([np.vectorize(g_f, otypes=[np.matrix])(x).reshape((1, -1)) for g_f in g], dtype=float, casting='unsafe') #Casting 'unsafe' permite a la función castear arrays (object) a arrays de float. Dará errores si no se cumple el contrato

    
def objective1(trial, serie_temporal, F):
    """rad
      Es llamada por la funcion optimizacion
      Optimiza usando el diccionario armónico
    """
    #global serie_temporal
    p = trial.suggest_float("p", 0.5, 0.9)
    T = trial.suggest_float("T", 1, 10)
    n = trial.suggest_int("n", 1, 50)
    def sacar_senos(n, T):
        return lambda x: np.sin(((2*np.pi*n)/T)*x)
    def sacar_cosenos(n, T):
        return lambda x: np.cos(((2*np.pi*n)/T)*x)
    senos = [sacar_senos(i, T) for i in range(1, n+1)]
    cosenos = [sacar_cosenos(i, T) for i in range(1, n+1)]
    funciones_lista=[]
    funciones_lista = [(lambda x: x,) , (lambda x: 1,)]
    funciones_lista.append(senos)
    funciones_lista.append(cosenos)
    funciones_lista= list(itertools.chain.from_iterable(funciones_lista))
    static_dicts: list[list[Callable[[float], float]]] = [funciones_lista]
    g = create_fdict(static_dicts[0])
    resultado = prediccion_con_calidad(serie_temporal, g, F, p)
    # Negativo porque optuna minimiza!
    return -resultado[1][3] 

def objective2(trial, serie_temporal, F):
    """rad
      Es llamada por la funcion optimizacion
      Optimiza usando el diccionario polinómico
    """
    #global serie_temporal
    p = trial.suggest_float("p", 0.5, 0.9)
    indx_g = trial.suggest_int("indx_g", 0, 2**8-2)
    funciones_posibles = [lambda x: 1, lambda x: x**2, lambda x: x**3, lambda x: x**4,
                          lambda x: x**5, lambda x: x**6, lambda x: x**7, lambda x: x**8, lambda x: x**9]

    funciones_combi = [itertools.combinations(funciones_posibles, i) for i in range(0, len(funciones_posibles)+1)]

    funciones_lista = [(lambda x: x,) + combi for combi in itertools.chain(*funciones_combi)]
    
    static_dicts: list[list[Callable[[float], float]]] = funciones_lista
    g = create_fdict(static_dicts[indx_g])
    resultado = prediccion_con_calidad(serie_temporal, g, F, p)
    # Negativo porque optuna minimiza!
    return -resultado[1][3] 

def optimizacion(serie_temporal, F):
    """rad
      Ejecuta durante 10s y devuelve los mejores g, F y p que ha encontrado para
      esa serie temporal, y el MASE obtenido.
      
      La idea es que se ejecute varias veces y solo se quede con la sugerencia
      si el MASE obtenido es mejor que el que había antes.
    """
    study1 = optuna.create_study()
    study1.optimize(lambda trial: objective1(trial, serie_temporal, F), n_trials=1000, timeout=5)
    study2 = optuna.create_study()
    study2.optimize(lambda trial: objective2(trial, serie_temporal, F), n_trials=1000, timeout=5)
    # El resultado está negativo, menor resultado == mejores parámetros
    if study1.best_value<study2.best_value:
        n = study1.best_params["n"]
        T = study1.best_params["T"]
        def sacar_senos(n, T):
            return lambda x: np.sin(((2*np.pi*n)/T)*x)
        def sacar_cosenos(n, T):
            return lambda x: np.cos(((2*np.pi*n)/T)*x)
        senos = [sacar_senos(i, T) for i in range(1, n+1)]
        cosenos = [sacar_cosenos(i, T) for i in range(1, n+1)]
        funciones_lista=[]
        funciones_lista = [(lambda x: x,) , (lambda x: 1,)]
        funciones_lista.append(senos)
        funciones_lista.append(cosenos)
        funciones_lista= list(itertools.chain.from_iterable(funciones_lista))
        static_dicts: list[list[Callable[[float], float]]] = [funciones_lista]
    
        return create_fdict(static_dicts[0]), study1.best_params["p"], -study1.best_value
    else:
        funciones_posibles = [lambda x: 1, lambda x: x**2, lambda x: x**3, lambda x: x**4,
                              lambda x: x**5, lambda x: x**6, lambda x: x**7, lambda x: x**8, lambda x: x**9]
        funciones_combi = [itertools.combinations(funciones_posibles, i) for i in range(0, len(funciones_posibles)+1)]
        funciones_lista = [(lambda x: x,) + combi for combi in itertools.chain(*funciones_combi)]
        static_dicts: list[list[Callable[[float], float]]] = funciones_lista
        return create_fdict(static_dicts[study2.best_params["indx_g"]]), study2.best_params["p"], -study2.best_value


# if __name__ == "__main__":
#     import pandas as pd
#     df_anonimizada = pd.read_csv(r'df_anonimizada.csv')
#     df_anonimizada = df_anonimizada.iloc[: , 1:] 
#     serie_temporal = df_anonimizada.iloc[0].to_numpy()
#     F=2
#     a = optimizacion(serie_temporal, F)
#     print(a)
    