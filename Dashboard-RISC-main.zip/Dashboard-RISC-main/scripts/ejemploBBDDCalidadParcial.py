# -*- coding: utf-8 -*-
"""
Created on Wed Jun 25 13:27:15 2025

@author: Alumno
"""
from typing import Callable
import numpy as np
import pandas as pd
from scripts.koopman_model import create_fdict, prediccion_con_calidad
from scripts.optimizacion import optimizacion

# Suponemos que tenemos df_anonimizada
def main(serie):
    # df_anonimizada = pd.read_csv(r'assets\csvs\df_anonimizada.csv')
    # df_anonimizada = df_anonimizada.iloc[: , 1:] 
    # serie_temporal = df_anonimizada.iloc[0].to_numpy()

    serie_temporal = serie

    print(f"Serie temporal: {serie_temporal}")

    static_dicts: list[list[Callable[[float], float]]] = [
    [lambda x: x, lambda x: 1, lambda x: np.sin(x), lambda x: np.cos(x), lambda x: np.sin(2*x), lambda x: np.cos(2*x)],
    [lambda x: x, lambda x: 1, lambda x: x**2, lambda x: x**3, lambda x: x**4],
    [lambda x: x, lambda x: 1, lambda x: np.sin(x), lambda x: np.cos(x)],
    ]

    # Funcion en koopman_operator_prediction
    g = create_fdict(static_dicts[2])

    F = 2 # numero de predicciones
    p = 0.8 # porcentaje de training al calcular la calidad esperada

    # Funcion en koopman_operator_prediction
    resultado = prediccion_con_calidad(serie_temporal, g, F, p)
    print("antes nirm", resultado)
    result_norm = [x if x >= 0 else 0.0 for x in resultado[0]]

    resultado = (result_norm, resultado[1])
    print(f"Resultado de la predicción: {resultado}")
    # Funcion en optimizacion
    params_opt =optimizacion(serie_temporal, F)

    if params_opt[2] > resultado[1][3]: 
        # Funcion en koopman_operator_prediction
        resultado = prediccion_con_calidad(serie_temporal, params_opt[0], F, params_opt[1])
    
    return resultado

if __name__ == "__main__":
    main()