from dash import Input, Output, html, dcc
import plotly.graph_objs as go
from assets import consts
from utils.helpers import get_metric_style_and_text
import scripts.ejemploBBDDCalidadParcial as pred_calidad
import scripts.threats_simulation as sim

import random

def register_callbacks(app):
    @app.callback(
        Output('output-content', 'children'),
        Input('threat-dropdown', 'value'),
        Input('interval-input', 'value')
    )
    def update_output(threat, interval_value):
        if not threat:
            return html.Div("Selecciona una amenaza para visualizar los análisis", className="text-center text-muted py-5")
        manual, resample, pred, calidad = get_data()
        MDA, MDV, NMDV, MASE = calidad

        metrics = {
            "MDA": round(MDA, 4),
            "NMDV": round(NMDV, 4),
            "MASE": round(MASE, 4),
        }

        x_manual = list(range(len(manual)))
        x_resample = list(range(len(resample)))
        x_pred = list(range(len(manual), len(manual) + len(pred)))

        line_fig = go.Figure()
        line_fig.add_trace(go.Scatter(x=x_manual, y=manual, name="Manual", line=dict(dash='dash', color=consts.COLOR_SKY_BLUE)))
        line_fig.add_trace(go.Scatter(x=x_resample, y=resample, name="Resample", line=dict(dash='dash', color=consts.COLOR_RED)))
        line_fig.add_trace(go.Scatter(x=x_pred, y=pred, name="Predicción", line=dict(dash='solid', color=consts.COLOR_ORANGE_AMBER)))
        line_fig.update_layout(title=f"📈 Serie Temporal + Predicción para '{threat}'", template='plotly_white')

        bar_fig = go.Figure()
        bar_fig.add_trace(go.Bar(x=x_manual, y=manual, name="Manual", marker_color=consts.COLOR_SKY_BLUE))
        bar_fig.add_trace(go.Bar(x=x_resample, y=resample, name="Resample", marker_color=consts.COLOR_RED))
        bar_fig.add_trace(go.Bar(x=x_pred, y=pred, name="Predicción", marker_color=consts.COLOR_ORANGE_AMBER))
        bar_fig.update_layout(title=f"📊 Distribución + Predicción para '{threat}'", barmode='group', template='plotly_white')

        pie_data = [{"label": opt, "value": random.randint(50, 500)} for opt in consts.THREAT_OPTIONS]
        pie_fig = go.Figure(data=[go.Pie(
            labels=[i['label'] for i in pie_data],
            values=[i['value'] for i in pie_data],
            marker=dict(colors=list(consts.COLOR_PALETTE)),
            hole=0.4
        )])
        pie_fig.update_layout(title="🥧 Distribución de Amenazas")

        metric_cards = html.Div([
            html.Div([
                html.Div([
                    html.H4(label, className="fw-bold"),
                    html.Div(f"{value}", className="h2 fw-bold", style={'color': consts.COLOR_DEEP_RED}),
                    html.Small(calidad_text, className="text-muted")
                ], style={'backgroundColor': bg_color}, className="shadow text-center p-3 rounded")
            ], className="col-12 col-md-4 mb-3")
            for label, value in metrics.items()
            for calidad_text, bg_color in [get_metric_style_and_text(label, value)]
        ], className="row justify-content-center")

        return html.Div([
            metric_cards,
            dcc.Graph(figure=line_fig),
            dcc.Graph(figure=pie_fig),
            dcc.Graph(figure=bar_fig),
        ], className="mt-4")

def get_data():
    data_series = sim.main()
    serie_manual = data_series[0]
    serie_resample = data_series[1]
    pred_quality = pred_calidad.main(serie_manual)
    return serie_manual, serie_resample, pred_quality[0], pred_quality[1]
