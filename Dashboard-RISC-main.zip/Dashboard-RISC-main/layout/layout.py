from dash import html, dcc
import dash_bootstrap_components as dbc
from assets.consts import COLOR_RED, COLOR_GRAY, COLOR_CHARCOAL, FONT_FAMILY, FINANCIAL_TEXT
def create_layout():
    return html.Div([
        html.Div([  # Contenedor del contenido (header, dropdown, gráficas, etc.)
            dbc.Container([
                html.Div([
                    html.H1("Dashboard de Amenazas INCIBE", className="text-center", style={
                        'color': COLOR_RED,
                        'fontFamily': FONT_FAMILY
                    }),
                    html.P("Sistema avanzado de análisis y predicción de ciberamenazas",
                           className="text-center mb-4", style={
                        'color': COLOR_GRAY,
                        'fontFamily': FONT_FAMILY
                    }),
                ], className="py-4"),

                html.Div([
                    html.Label("⏱️ Intervalo (segundos):", className="form-label fw-bold text-center d-block", style={
                        'color': COLOR_CHARCOAL,
                        'fontFamily': FONT_FAMILY
                    }),
                    dcc.Input(
                        id="interval-input",
                        type="number",
                        min=60,
                        step=60,
                        value=3600,
                        className="mb-4 d-block mx-auto",
                        style={'textAlign': 'center'}
                    )
                ]),

                html.Div([
                    html.Label("🎯 Selecciona el tipo de amenaza:", className="form-label fw-bold text-center d-block", style={
                        'color': COLOR_CHARCOAL,
                        'fontFamily': FONT_FAMILY
                    }),
                    dcc.Dropdown(
                        id='threat-dropdown',
                        options=[{'label': i, 'value': i} for i in [
                            'Bot,C&C', 'Botnet', 'C&C', 'Compromised', 'DGA', 'Defacement',
                            'Exposed', 'Fake', 'Malicious', 'Malware', 'Phishing',
                            'Security check', 'Spam', 'Tor', 'Vulnerable'
                        ]],
                        placeholder="🔍 Elige una amenaza para analizar",
                        className="mb-4",
                        style={'width': '100%', 'maxWidth': '400px', 'margin': '0 auto'}
                    ),
                ]),

                dcc.Loading(
                    id="loading-output",
                    type="circle",
                    children=html.Div(id='output-content'),
                    fullscreen=False,
                    color=COLOR_RED
                ),
            ], fluid=True)
        ], id="main-content", className="flex-grow-1"), 

        html.Footer([
            html.Hr(),
            html.Small(FINANCIAL_TEXT),
            html.Img(src="/assets/logos-incibe.png", style={
                'display': 'block',
                'margin': '0 auto',
                'maxWidth': '800px'
            })
        ])
    ], className="d-flex flex-column min-vh-100") 

