# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 19:59:06 2025
@author: amunc
"""

## Paquetes ###################################################################
from random import choices, randrange
import datetime 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import dotenv
dotenv.load_dotenv()

#%% Generación de base de datos simulada ###########################################

# Número de eventos simulados
n = 1000

# Lista de fuentes ficticias (caracteres a-z) y amenazas desde la variable de entorno
fuente = list('abcdefghijklmnopqrstuvwxyz')
# threat_str = os.getenv("THREAT", "")
# threat =  [t.strip() for t in threat_str.split(",") if t.strip()]
threat = ['bot', 'spyware', 'phishing', 'virus', 'worm', 'backdoor']

# Generar columnas simuladas para 'source' y 'threat'
df1 = choices(fuente, k=n)
df2 = choices(threat, k=n)

# Función generadora de fechas aleatorias desde un punto inicial
def random_date(start, l):
    current = start
    while l >= 0:
        curr = current + datetime.timedelta(minutes=randrange(60 * 24))
        yield curr
        l -= 1

# Crear una lista ordenada de timestamps aleatorios
startDate = datetime.datetime(2025, 6, 17, 0, 0)
df3 = list(random_date(startDate, n - 1))
df3.sort()

# Construcción del DataFrame simulado
df = pd.DataFrame([df3, df1, df2]).transpose()
df.columns = ['timestamp', 'source', 'threat']
df['timestamp'] = pd.to_datetime(df['timestamp'])

#%% Visualización de resultados ####################################################
def generateFigures(serie_manual, serie_resample, target, dtau_seconds):
    """
    Genera gráficos comparativos (líneas y barras) entre conteo manual y por resample.

    Parámetros:
        serie_manual (np.ndarray): Serie temporal generada de forma manual.
        serie_resample (np.ndarray): Serie generada con Pandas resample().
        target (str): Amenaza específica a visualizar.
        dtau_seconds (int): Intervalo de tiempo en segundos.
    """

    # Mostrar gráfico de líneas
    plt.figure(figsize=(10, 4))
    plt.plot(serie_manual, label='Manual', linestyle='--', marker='o', alpha=0.7)
    plt.plot(serie_resample, label='Resample', linestyle='--', marker='x', alpha=0.7)
    plt.title(f"Comparación de series para amenaza '{target}' cada {dtau_seconds//60} min")
    plt.xlabel("Intervalo de tiempo")
    plt.ylabel("Número de ocurrencias")
    plt.legend()
    plt.tight_layout()
    plt.show(block=False)

    # Mostrar gráfico de barras
    x = np.arange(len(serie_manual))
    bar_width = 0.4
    plt.figure(figsize=(10, 4))
    plt.bar(x - bar_width/2, serie_manual, width=bar_width, label='Manual', alpha=0.7)
    plt.bar(x + bar_width/2, serie_resample, width=bar_width, label='Resample', alpha=0.7)
    plt.title(f"Comparación de series (barras) para amenaza '{target}' cada {dtau_seconds//60} min")
    plt.xlabel("Intervalo de tiempo")
    plt.ylabel("Número de ocurrencias")
    plt.legend()
    plt.tight_layout()
    plt.show()


#%% Conteo manual de eventos por intervalo #########################################
def integrar_tabla(df, idx, target, dtau_seconds):
    """
    Cuenta el número de ocurrencias del target en intervalos fijos, de forma manual.

    Parámetros:
        df (pd.DataFrame): DataFrame con columnas 'timestamp', 'source', 'threat'.
        idx (int): Índice de columna (por ejemplo, 2 para 'threat').
        target (str): Valor específico a contar.
        dtau_seconds (int): Duración del intervalo en segundos.

    Retorna:
        np.ndarray: Serie temporal de conteo por intervalo.
    """


    df = df.copy()
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    dtau = datetime.timedelta(seconds=dtau_seconds)
    dtau_int = int(dtau.total_seconds())

    dtimetotal = df['timestamp'].iloc[-1] - df['timestamp'].iloc[0]
    dtimetotal_int = int(dtimetotal.total_seconds())

    df_alt = df.copy()
    df_alt['interval'] = ((df['timestamp'] - df['timestamp'].iloc[0]).dt.total_seconds() // dtau_int).astype(int)

    cuantos_ts = (dtimetotal_int // dtau_int) + 1
    x = np.zeros(cuantos_ts)

    colname = df.columns[idx]
    filtered_df = df_alt[df_alt[colname] == target]

    if not filtered_df.empty:
        counts = filtered_df.groupby('interval').size()
        valid_indices = counts.index[counts.index < cuantos_ts]
        x[valid_indices.astype(int)] = counts.loc[valid_indices].values

    return x


#%% Conteo automático con resample de Pandas #######################################
def integrar_con_resample(df, idx, target, dtau_seconds):
    """
    Cuenta ocurrencias del target mediante resample desde el primer timestamp.

    Parámetros:
        df (pd.DataFrame): DataFrame con columnas 'timestamp', 'source', 'threat'.
        idx (int): Índice de columna (por ejemplo, 2 para 'threat').
        target (str): Valor específico a contar.
        dtau_seconds (int): Duración del intervalo en segundos.

    Retorna:
        np.ndarray: Serie temporal con el conteo por intervalo.
    """
    df = df.copy()
    print(df.head())
    df.columns = ['timestamp', 'source', 'threat']
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Obtener el primer timestamp
    start_time = df['timestamp'].min()
    end_time = df['timestamp'].max()

    # Calcular número de intervalos (igual que integrar_tabla)
    total_duration_seconds = int((end_time - start_time).total_seconds())
    num_intervals = total_duration_seconds // dtau_seconds + 1
    
    # Crear índice con todos los intervalos necesarios
    full_index = pd.date_range(start=start_time, periods=num_intervals, freq=f"{dtau_seconds}s")

    # Crear columna de alineación
    df['aligned_timestamp'] = start_time + (df['timestamp'] - start_time)
    df.set_index('aligned_timestamp', inplace=True)

    columna = df.columns[idx]

    # Filtrar por amenaza y hacer resample
    filtered = df[df[columna] == target]
    serie = filtered.resample(f"{dtau_seconds}s", origin=start_time).size()

    # Reindexar para forzar los ceros (igual que en la versión manual)
    serie = serie.reindex(full_index, fill_value=0)

    return serie.to_numpy()

#%% Función principal #############################################################
def main():
    target = "backdoor"
    dtau_seconds = 3600

    serie_manual = integrar_tabla(df.copy(), 2, target, dtau_seconds)
    serie_resample = integrar_con_resample(df.copy(), 2, target, dtau_seconds)

    print(f"Serie manual: {serie_manual}")
    print(f"Serie resample: {serie_resample}")
    generateFigures(serie_manual, serie_resample, target, dtau_seconds)


if __name__ == "__main__":
    main()