
📈 Time Series Applications to MICS

Aplicación de series temporales a datos simulados del MICs.

---

## 📂 Estructura del proyecto

```plaintext
.
├── Documentos/                          # Archivos y documentación relacionada
├── EjemploSerieTemporalIntegracion.py   # Script para generación y análisis básico de series temporales
├── Ejemplo_BBDD_parcial.py              # Ejemplo de la base de datos
├── Optimizacion.py                      # Script con funciones para optimizar
├── README.md                            # Este archivo
├── df_anonimizada.csv                   # Base de datos anonimizada
├── koopman_operator_prediction.py       # Módulo que implementa predicción de series temporales mediante aproximación del operador de Koopman.
├── obtencionSerieTemporal_v1.py         # Script con versiones manual y automática (resample) del análisis temporal
└── requirements.txt                     # Dependencias necesarias para ejecutar los scripts

```
---
## 🗄️ Base de Datos Anonimizada
### `df_anonimizada.csv`
- Base de datos anonimizada
  - Columnas:
  - Filas: 
---

## 🧠 Descripción de los scripts

### `EjemploSerieTemporalIntegracion.py`

- Genera una base de datos sintética con eventos de amenazas, cada uno con:
  - una marca de tiempo (timestamp)
  - una fuente
  - un tipo de amenaza
- Cuenta la frecuencia de un tipo específico de amenaza en intervalos de tiempo regulares (por ejemplo, por hora).
- Visualiza la serie temporal resultante con gráficos.

### `obtencionSerieTemporal_v1.py`

- También crea datos sintéticos de amenazas.
- Implementa dos métodos para construir la serie temporal:
  - 🔧 Versión manual: cuenta eventos agrupándolos por intervalos de tiempo definidos.
  - ⚙️ Versión con `pandas.resample`: método más eficiente y elegante.
- Compara ambas series para asegurar que producen los mismos resultados.
- Incluye gráficos comparativos para visualización y validación.

### `koopman_operator_prediction.py`
- Crea diccionarios de funciones estáticos con `create_fdict`
- Aproxima el operador de Koopman dada una serie temporal, un diccionario de funciones y una ventana de aproximación con `get_koopman`
- Predice el siguiente valor de una serie temporal con `one_step_pred`
- Evalua la aproximación para un dataset X = {x(t), ..., x(t+m}) con porcentaje de entrenamiento p usando la función `predict_test`
- Efectua Rolling Cross Validation para un dataset X = {x(t), ..., x(t+m}) usando `rolling_cross_validation`
- Evalua las predicciones realizadas mediante MDA, MDV y NMDV.
---
