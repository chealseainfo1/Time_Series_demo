Carpeta con documentos importantes.

- IN-Camposdeeventos.Significado,camposcomunes-160625-1526-87 : Información de los campos y valores de la muestra de datos porporcionada por el INCIBE
- Resumen_On_Aggregation_and_Prediction_of_Cybersecurity_Incident_Reports : Resumen artículo proporcionado sobre Aplicación de series temporales de datos
