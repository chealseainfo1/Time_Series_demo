# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 19:59:06 2025

@author: amunc
"""
## Paquetes ###################################################################
from random import choices, randrange
import datetime 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#%% Crear database de mentirijilla ###############################################################################

n=1000

fuente = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
threat = ["bot", "spyware", "phising", "virus", "worm", "backdoor"]
df1=choices(fuente, k=n)
df2=choices(threat, k=n)


def random_date(start,l):
   current = start
   while l >= 0:
      curr = current + datetime.timedelta(minutes=randrange(60*24))
      yield curr
      l-=1


startDate = datetime.datetime(2025, 6, 17, 00,00)


df3=list(random_date(startDate,n-1))
df3.sort()

df=pd.DataFrame([df3, df1, df2]).transpose()
df[0] = pd.to_datetime(df[0])
print(df)

del df1, df2, df3, fuente, startDate, threat, n

#%% Ahora el plato principal #######################################################
n=1000
# El intervalo temporal diferencial es una hora
# Considerando que hay 24, tampoco es demasiado pequeño. Podría serlo más.
dtau = datetime.timedelta(seconds=3600)
dtau_int = int(dtau.total_seconds()) # dtau como entero para hacer cuentas luego 

# Intervalo total representado
dtimetotal = df.iloc[n-1,0]-df.iloc[0,0]
dtimetotal_int = int(dtimetotal.total_seconds()) # intervalo total como entero para hacer cuentas luego 

# Sano respeto a editar la base de datos original
df_alt = df.copy()
# Cambio el tiempo a "segundos desde el comienzo"
df_alt[0] = (df.iloc[:, 0] - df.iloc[0, 0]).dt.total_seconds().astype(int)
# Cambio segundos desde el comienzo a dtaus enteros desde el comienzo
df_alt[0] = df_alt[0] // dtau_int

# Cuántos intervalos tengo?
cuantos_ts = (dtimetotal_int // dtau_int) + 1

# Qué estoy contando
target = "worm"

# Inicializar serie temporal
x = np.zeros(cuantos_ts)

# Contador en cada dtau
counts = df_alt[df_alt[2] == target].groupby(0).size()
x[counts.index.astype(int)] = counts.values

# Pintar :)
plt.plot(x)
plt.show()

#%% Hazlo una función #########################################################
def integrar_tabla(df, idx, target, dtau_seconds):
    """
    Integra el indicador de target sobre la tabla en intervalos dtau.

    Parámetros:
    df (pd.DataFrame): Base de datos.
                        df[0] son los tiempos en date.time.
    idx (float, int): Índice de la columna en la que filtramos.
    target (string): Con lo que queremos hacer match para filtrar.
    dtau_seconds (int, float): Tiempo en segundos de cada intervalo.

    Devuelve:
    np.array(floats) : La serie temporal.
    """
    #Aseguramos que la columna time es datetime
    df[0] = pd.to_datetime(df[0]) 

    dtau = datetime.timedelta(seconds=dtau_seconds)
    dtau_int = int(dtau.total_seconds())

    # Intervalo total representado
    dtimetotal = df.iloc[len(df) - 1, 0] - df.iloc[0, 0]
    dtimetotal_int = int(dtimetotal.total_seconds())

    # Sano respeto a editar la base de datos original
    df_alt = df.copy()

    # Cambio el tiempo a "segundos desde el comienzo"
    df_alt[0] = (df.iloc[:, 0] - df.iloc[0, 0]).dt.total_seconds().astype(int)
    # Cambio segundos desde el comienzo a dtaus enteros desde el comienzo
    df_alt[0] = df_alt[0] // dtau_int

    # Cuántos intervalos tengo?
    cuantos_ts = (dtimetotal_int // dtau_int) + 1

    # Inicializar serie temporal
    x = np.zeros(cuantos_ts)

    # Contador en cada dtau
    filtered_df = df_alt[df_alt[idx] == target]
    if not filtered_df.empty:
        counts = filtered_df.groupby(0).size()
        
        valid_indices = counts.index[counts.index < cuantos_ts]
        x[valid_indices.astype(int)] = counts.loc[valid_indices].values

    return x

#%% Funciona :) ###############################################################
print(df)
print(integrar_tabla(df, 2, "backdoor", 3600))





 
